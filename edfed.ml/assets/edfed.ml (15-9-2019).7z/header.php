<!--Start Default CSS for each page-->
<style type="text/css">
body {
    position: relative;
}

#comments {
    display: none;
}
</style>
<!--End Default CSS for each page-->

<?php
 # other link format: <link rel="stylesheet" type="text/css" href="https://bootswatch.com/4/darkly/bootstrap.min.css">
if ($_SESSION['theme']== 'cyborg') {
	echo '<meta name="theme-color" content="maroon">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootswatch/4.3.1/cyborg/bootstrap.min.css">';

	echo '
	<style type="text/css">
	#tablediv {
		margin-top: 68px;
	}

	.jumbotron {
		background-image: url(background-night.jpg);
		text-align: center;
	}

	@media only screen and (max-width: 600px) {
		#tablediv {
			margin-top: 54px;
		}
	}
	</style>';
}
if ($_SESSION['theme']== 'darkly') {
	echo '<meta name="theme-color" content="black">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootswatch/4.1.1/darkly/bootstrap.min.css">';

	echo '
	<style type="text/css">
	#tablediv {
		margin-top: 84px;
	}

	.jumbotron {
		background-image: url(background-night.jpg);
		text-align: center;
	}

	@media only screen and (max-width: 600px) {
		#tablediv {
			margin-top: 70px;
		}
	}
	</style>';
}

if ($_SESSION['theme']== 'litera') {
	echo '<meta name="theme-color" content="pink">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootswatch/4.3.1/litera/bootstrap.min.css">';

	echo '
	<style type="text/css">
	#tablediv {
		margin-top: 71px;
	}

	.jumbotron {
		background-image: url(background.jpg);
		text-align: center;
	}

	@media only screen and (max-width: 600px) {
		#tablediv {
			margin-top: 62px;
		}
		.badge {
			font-size: 50%;
			padding: 0.3em 0.4em;
			margin-bottom: 6px;
		}
	}
	</style>';
}
if ($_SESSION['theme']== 'normal') {

	echo '<meta name="theme-color" content="#253a53">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">';

	echo '<style type="text/css">
	#tablediv {
		margin-top: 70px;
	}

	.jumbotron {
		background-image: url(background.jpg);
		text-align: center;
	}

	@media only screen and (max-width: 600px) {
		#tablediv {
			margin-top: 54px;
		}
	}
	</style>';
}
if ($_SESSION['theme']== 'no-one') {
	echo '<meta name="theme-color" content="white">
	<!--No Theme Specified-->';
}
?>